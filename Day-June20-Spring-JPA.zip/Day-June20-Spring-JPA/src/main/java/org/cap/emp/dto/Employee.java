package org.cap.emp.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
@Table(name="Employee_info")
public class Employee {
	
	@Id
	@GeneratedValue
	private int empId;
	@NotEmpty(message="*Please enter FirstName.")
	private String firstName;
	private String lastName;
	
	@Range(max=500000,min=10000,message="*Salary should be between 10000 and 5 laks.")
	private double salary;
	
	@Past(message="* Date of birth must be past Date.")
	private Date empDob;
	
	public Employee(){}
	
	public Employee(int empId, String firstName, String lastName, double salary, Date empDob) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.empDob = empDob;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", empDob=" + empDob + "]";
	}
	
	

}
